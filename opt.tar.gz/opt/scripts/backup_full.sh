#/bin/bash

#opcion de ayuda (punto 5)
if [ "$1" == "-help" ]; then
	echo "Uso: /opt/scripts/backup_full.sh [origen] [destino]"
	echo "Ejemplo: /opt/scripts/backup_full.sh /var/log /backup_dir"
	exit 0
fi

#validar que el usuario ingrese exactamente los 2 argumentos (punto 4)
if [ "$#" -ne 1]; then
	echo "Error: se requieren 2 argumentos (origen y destino)."
	echo "Use -help para ver el manual de uso."
	exit 1
fi

ORIGEN=$1
DESTINO=$2
FECHA=$(date +%Y%m%d)
NOMBRE_DIR=$(basename "$ORIGEN")

#validacion de existencia (el origen y destino deben existir) punto6
if [ ! -d "$ORIGEN" ]; then
	echo "Error: EL directorio de origen $ORIGEN no existe."
	exit 1
fi

if [ ! -d "$DESTINO" ]; then
	echo "Error: EL directorio de destino $DESTINO no existe."
	exit 1
fi

#Realizar backup comprimido Punto 2 y 3
tar -cvzf "$DESTINO/${NOMBRE_DIR}_bkp_$FECHA.tar.gz" "$ORIGEN"

